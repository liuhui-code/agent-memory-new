---
name: agent-memory-query
description: Use when the user asks to query, search, recall, inspect, design against, or retrieve project memory, code, logs, incidents, impact evidence, ADRs, Feature Specs, or codebase wiki context.
---

# Agent Memory Query

Route the request to one focused protocol and query bounded project memory for the local Agent CLI. The Runtime returns historical experience, code-log keywords, current code anchors, and stored graph edges. The Agent CLI owns temporary-log analysis, candidate causes, call/causal chains, diagnosis, design decisions, and verification.

## Route

Choose one primary protocol. Do not load every reference.

| Intent | Primary protocol |
|---|---|
| Understand files, symbols, routes, resources, or current behavior | `references/code-understanding.md` |
| Diagnose an error, symptom, runtime log, or incident | `references/incident-diagnosis.md` |
| Review a change, regression risk, affected files, or test scope | `references/change-impact.md` |
| Design a feature, refactor, interface, state flow, or module boundary | `references/code-design.md` |
| Recall or judge historical memory, corrections, or trust | `references/evidence-policy.md` |

If multiple intents apply, start with the user's requested outcome. Load a second protocol only when the first protocol explicitly requires that handoff.

## Selective Retrieval

Use the cheapest investigation level that can answer the request:

- **L0 current source first:** when the user supplies a file/line, compiler symbol, failing test, route, resource key, or configuration value that can be checked within three files and two source searches. Do not call Memory if current source and a direct verification settle the issue.
- **L1 compact context:** when the request contains a runtime log/error code, has no known emitter, crosses modules, lifecycle/callback/async boundaries, has competing causes, depends on business meaning, asks about history, or remains unresolved after the L0 budget.
- **L2 focused expansion:** query one exact log phrase, symbol, or Agent-produced candidate at a time with `--compact`. Remove `--compact` only to inspect full records, ranking audit, or one unresolved evidence conflict.

Memory selection is an Agent workflow decision, not a Runtime diagnosis. Never skip an explicit user request to query memory.

## Default Command

Use the compact historical query entry for L1 diagnosis and code understanding:

```bash
python3 tools/agent_memory.py context --project . --query "<user problem or Agent-extracted term>" --compact --json
```

When the lane is clear or domain words are ambiguous, pass typed `--intent`; load `references/evidence-policy.md` for values, audit fields, and cross-language handling.

For L2 audit expansion, run the same focused query without `--compact`. The full view is not the default Agent injection path.

For a design request, use the dedicated context facade:

```bash
python3 tools/agent_memory.py design-context --project . --query "<design goal>" --compact --json
```

The Runtime returns repository facts, project constraints, quality questions,
general design references, history, and evidence gaps. It does not recommend a
pattern or produce a design. Load `references/code-design.md`; the Agent owns
concern selection, alternatives, tradeoffs, the final design, and its plan.

Use `search` or `wiki-search` only when the selected protocol calls for a broader or code-only view. Do not pass temporary runtime-log files to Agent Memory.

## Normative Context

Inspect omission counts when this lane is present. `examined_document_count` covers
bounded candidates, while `candidate_limit_exceeded` marks additional unexamined
matches. `omitted_document_count` and `omitted_evidence_gap_count` accumulate known
omissions across selection, compact projection and budget reduction. Do not treat
those counts as total matching-document coverage. `truncated` also covers partial
body text; read the original for a complete contract. Full gap provenance and cached
record IDs distinguish documents from different source roots.

For stable product behavior or architecture decisions, inspect
`query_handoff.normative_context` in `context`, or
`project_context.normative_context` in `design-context`. Use the existing task route;
do not query every ADR and specification for an unrelated local task.

- Read the document's source root, path, digest, declared status, scope, approval
  reference, replacement references, freshness and `allowed_use`.
- `source.digest` identifies indexed raw bytes; `source.observed_digest` identifies
  this query's bounded read, or is null when unavailable. Compare the two without
  treating an observation as refreshed metadata or authenticated approval. The
  recorded revision belongs to learning time; Git state and bytes are separate
  observations rather than an atomic repository snapshot.
- Scope belongs to `scope_basis: document_source_root`. `source.matches_query_project`
  compares roots only. Confirm external-tree applicability against the current task,
  including global scopes marked `source_root_requires_agent_confirmation`.
- `expected_contract_candidate` means the metadata and current source permit review;
  it is not independently verified approval. Read the original Git document and its
  approval evidence before treating it as an applicable project constraint.
- Keep drafts as hypotheses and superseded/withdrawn/rejected documents as historical
  references. Resolve duplicate IDs and replacement claims before applying either.
- `replacement_lookup` describes bounded cached metadata in the same source root;
  `not_indexed`, `ambiguous` and `unique` refer only to that cache. Read both original
  documents for approval, scope and reciprocal claims. Target-source and approval flags
  remain false in this lookup; a linked record is not an inspected source or an approved
  replacement merely because it appears. Metadata gaps do not adjudicate invalidity.
- Changed, missing, untracked or modified documents require source/approval review.
  A fresh digest or a Git commit alone never proves approval.
- When `truncated` is true or an omission count is greater than zero, expand the same
  focused query without `--compact`, or read the cited source. An excerpt is not the
  full contract; candidate overflow also leaves matches unexamined.
- Report expected behavior and observed implementation separately when they disagree.
  The Agent owns diagnosis and design; Runtime does not choose which side is correct.

If a relevant document has not been learned, read it directly or use the existing Learn
Skill on that explicit scope. Keep the current task intent temporary; do not synthesize
an approved Feature Spec from the user's prompt or current implementation.

## Authority

Use evidence in this order:

```text
explicit user constraints
  -> current source and current configuration
  -> active typed graph edges and current code logs
  -> observed runtime/incident evidence
  -> anchored semantic corrections
  -> verified experience
  -> advisory experience and episodes
```

Current source can invalidate memory. Recency cannot override intent, status, confidence, counter-evidence, or a current code anchor. An absent graph edge is an evidence gap, not proof that no dependency exists.

Treat experience candidates as advisory decision frames; verify them against current source, logs, tests, and code wiki evidence before use.

Read `references/evidence-policy.md` when the answer relies materially on reflections, semantic patches, conflict notes, trust labels, or retrieval feedback.

## Bounded Work

- Start from the user's natural-language goal.
- Apply the L0 budget before Memory only when the problem already has a precise current-source anchor.
- Prefer exact file, symbol, route, resource, log, request, or session anchors for follow-up queries.
- Respect query round, cursor, graph-depth, and result limits.
- Read compact `query_handoff.log_keywords`, code/log anchors, path candidates, relation hints, correction guards, and evidence gaps first.
- Analyze temporary runtime logs directly in the Agent session.
- Query each Agent-produced candidate cause separately; do not combine all candidates into one broad query.
- Infer call chains and causal chains from current source and runtime order in the Agent session.
- Never treat ranking, stored edges, or historical experience as a Runtime-produced diagnosis.
- Do not run merge, promotion, stale marking, or vault export from this skill.

## Source Exploration Control

For compact diagnosis and code-understanding results, follow
`query_handoff.source_exploration`:

1. Inspect `code_anchors` with `role=primary` first.
2. Treat `source_excerpts` as bounded current-worktree evidence: do not reread those lines, and open source only for a named gap outside them. Without excerpts, read `read_window` once rather than once per `source_range`.
3. Stop only when an inspected causal file shows the concrete mechanism, with no direct contradiction and a verification path. A likely owner or intended behavior is not direct mechanism evidence.
4. Inspect `role=expansion` or non-anchor files only for one named `allowed_expansion_reasons`.
5. Record each round in `expansion_trace`; close one gap and add at most two files.
6. Respect the returned total-file, search, and expansion-round budgets.
7. On budget exhaustion or no new evidence, report uncertainty instead of
   continuing broad source exploration.

Before `supported_cause_found`, report direct `evidence_basis` and inspected
`mechanism_evidence_files`; they may span supporting boundaries but must include
one predicted owner. Otherwise use `inference_only` and an uncertainty stop.

Do not expand because another file is merely related. The Agent chooses the
reason, evaluates evidence sufficiency, and reports the stop condition; the
Runtime only supplies the contract and anchors.

When reporting a diagnosis, separate root-cause or repair-owner files from
supporting callers, boundaries, and corroborating files. Supporting files stay
in the evidence trail but must not be presented as causal owners.

## Output

Return only query results needed for the selected intent. Cite inspectable files, symbols, stored edges, code-log templates, or record ids. Separate current code, historical advice, and search misses. The local Agent CLI must summarize the user log, form competing causes, reconstruct call/causal chains from source, and verify its conclusion.

## Task-End System Review Handoff

At the end of a real Memory-related logical task with an observed system signal, hand
the bounded observations and retained task identity to the installed Reflect Skill's
[system-review protocol](../agent-memory-reflect/references/system-meta-review.md).
Do this after the task, not per query or inside the query response. Respect current stops,
budgets and the no-recursion rule; ordinary empty/freshness results alone do not trigger it.
If that Skill/reference is absent, retain the limitation instead of assuming a hook ran.
