---
name: agent-memory-maintain
description: Use when the user asks to initialize, check health, update, repair, refresh, or sync Agent Memory or its Obsidian vault, or review a system-change proposal.
---

# Agent Memory Maintain

Use this skill for memory system health and maintenance.

## System-Change Proposals

For a proposal to change Agent Memory's rules, implementation or data model, or an
explicit meta-review follow-up, read
[references/system-evolution.md](references/system-evolution.md) before the ordinary
health/review workflow. It covers rule, Query, Learn, Reflect, evaluator and data-model
changes, development artifacts, check states, compatibility and separate code/data recovery.

Do not automatically run health, eval or database-changing commands just to consume a
proposal. Use available evidence and current authorization; a skip-verification instruction
keeps checks unexecuted. The new explicit governance commands persist and read isolated
reviews/proposals, record limited state changes and optionally execute an explicit bounded
check plan. Read [references/system-checks.md](references/system-checks.md) only for that
authorized checking step, and [references/system-candidates.md](references/system-candidates.md)
when preparing an isolated Git-patch subject. For reviewed acceptance, explicit application,
post-application checks, schema migration or rollback, read
[references/system-lifecycle.md](references/system-lifecycle.md). These source commands
have controlled regression coverage; no automatic release or expanded permission is implied.
For reviewing an applied proposal against its original hypothesis and later results, read
[references/system-outcomes.md](references/system-outcomes.md); its context reader is read-only.
For authorized durable round snapshots, assessment history and advisory decisions, read
[references/system-rounds.md](references/system-rounds.md); installation is an explicit backup-backed migration.
For a known authorized round reaching its predeclared observation window, read
[references/system-handoffs.md](references/system-handoffs.md) before one current-host assessment.
Before a proposed real-task activity, read
[references/system-campaign-readiness.md](references/system-campaign-readiness.md) and report missing inputs.

Memory data is stored in the current workspace `.agent-memory/` by default, next to `skills/` and `tools/`, not in the learned external source directory. Use `--memory-home <path>` when the user configured a custom location; otherwise the runtime uses `AGENT_MEMORY_HOME` or `./.agent-memory`.

## Initialize Or Repair

```bash
python3 tools/agent_memory.py init --project .
python3 tools/agent_memory.py doctor --project .
```

## Health Check

For a user requesting a human browsing/review/delete interface, start the foreground
local workbench with `python3 tools/agent_memory.py review-ui --project . --open`,
using the user's existing `--memory-home` when configured. Report the printed local URL
and stop method. Do not initialize, migrate, collect real activities or delete records
merely to open it. The page supports review/archive/restore and backup-protected deletion
of archived facts, episodes and reflections; code indexes are read-only. Regenerate the
Vault after organizing if requested. Keep ordinary Agent retrieval on the Query Skill.

```bash
python3 tools/agent_memory.py doctor --project .
python3 tools/agent_memory.py maintain-health --project . --json
```

## Refresh Learned Scopes

When the project source has changed and the learned code wiki may be stale:

```bash
python3 tools/agent_memory.py maintain-refresh-scope --project . --json
```

To refresh one previously learned scope only:

```bash
python3 tools/agent_memory.py maintain-refresh-scope --project . --scope-id 3 --json
```

Use this before broad `learn-path --replace` or `wiki-index` resets. It replays previously learned scopes from SQLite, refreshes current file/symbol/log/edge structure, retires removed-file structure, and returns `semantic_review_targets` so we can decide whether a focused `learn-business` pass is needed next.
After refresh, run `maintain-plan --json` if you want the drift to be translated into review actions such as `review_semantic_drift`, `mark_experience_stale_if_anchor_removed`, or `review_skill_pattern_staleness`.

When FTS content or generated code/log edges are damaged, repair only derived data:

```bash
python3 tools/agent_memory.py maintain-rebuild-derived --project . --target search --json
python3 tools/agent_memory.py maintain-rebuild-derived --project . --target graph --json
```

For an external learned tree, pass its original `--source`. Check `preserved`, relation counts, edge amplification, relation dominance, semantic adapter errors, and provider runs before accepting the rebuilt graph. Do not use `wiki-index --replace` merely to repair derived indexes.

ADR and Feature Spec documents follow the same previously learned scopes.
`maintain-health.normative_index` reports stored document/status counts and duplicate
identities, with a source/metadata sample of at most 20 recently indexed documents and
at most five review references. Inspect unexamined counts and truncation; it does not
certify approval, acceptance or the freshness of unsampled documents.
Review items include record ID, indexed `source_digest` and the sample read's
`observed_digest`, which is null when unavailable. The recorded revision still belongs
to learning time. Comparing these digests does not refresh the stored document.
Review references may include `replacement_lookup`: same-source-root cached targets,
ambiguous IDs and reciprocal declaration gaps. Its linked targets are not additional
checked source samples. Read both Git originals and approval evidence before deciding
whether the relationship applies; refresh does not resolve or approve it automatically.
`maintain-refresh-scope` refreshes their declared status, approval references, scope,
replacement links and source digest; deleted files or removed/invalid normative markers
retire the corresponding derived document rows. Refresh does not approve a document.
An explicit `--replace` learning operation rebuilds normative rows for that source root;
ordinary partial learning preserves other document scopes.
Entry refresh preserves `--depth 0`. A deleted learned entry or path under an existing
source root retires its cached scope; a missing source root remains a reported gap.
After adopting updated normative parsing rules, fully refresh existing affected Scopes
without `--changed-only` to reparse unchanged documents. Do not add `--replace` for this
purpose; a search-only rebuild does not apply the parser to cached source text.
Read `parse_stats.normative_index` for per-operation added/changed/unchanged paths,
retirement reasons, source-read issues and bounded previews. Review its `next_action`
before treating indexing as complete. A selected unreadable document retains its old
cache and provenance for review: source-read errors in normative extraction now abort
the current indexing batch, including replacement retirements, before Scope checkpoint
updates. With `--json`, inspect `normative-learning-error/v1`, the failed Scope ID,
`failed_batch` and `attempted_normative_index`; attempted counts are not committed changes.
Restore or review the source and retry that same existing Scope. Earlier successful
Scopes in the call remain committed; this is a batch rollback, not a command-wide one.
Successful querying still requires current-source and approval checks. Earlier learning
failures may abort before this structured normative report is returned.

`maintain-rebuild-derived --target search` also repairs the normative FTS index from
SQLite. It does not refresh Git content or validate approval. Change the reviewed Git
document first, then refresh its learned scope. Query reports changed/missing sources
and dirty/untracked Git documents as review gaps rather than silently reusing approval.
`vault-export` writes a generated `Normative Context` reference index and snapshots;
editing those mirrors never changes approval or synchronizes back to Git.
Mirrors link the original local file and show source freshness in the index. Changed,
missing or unverified source is explicitly marked before the retained old snapshot;
do not use that snapshot as current-source evidence. Operational last-context caches
retain normative excerpt positions without text and do not replace source review.
Mirrors label indexed and export-time observed digests separately; an unavailable
observation is explicit. Export does not approve or update the SQLite contract snapshot.

## Review Queue

When the user asks to review, clean, govern, merge, or check memory quality:

```bash
python3 tools/agent_memory.py maintain-review --project . --json
python3 tools/agent_memory.py reflect-review --project . --json
python3 tools/agent_memory.py miss-list --project . --status open --json
python3 tools/agent_memory.py maintain-plan --project . --json
```

Use `maintain-plan` to propose grouped actions before changing records.

When `maintain-health --json` returns `runtime_performance`, use it to spot operational pressure before broad maintenance work. High p95 latency, poor performance bands, or repeated non-ok statuses mean the next maintenance pass should stay narrow and may need archive/compact review before adding more data.
When `maintain-health --json` returns `last_quality_gate`, inspect it before broad maintenance. If the latest gate failed, use `summary.failed_gate_names` and the failed gate's `next_command_template` to rerun the specific eval before changing memory. When `quality_gate_delta` is present, use it to distinguish new failures from resolved failures.
When `maintain-plan` returns `review_quality_gate_failure`, keep the follow-up in the `quality_gate` lane. Rerun the listed `next_command_templates`, then decide whether the runtime behavior or the golden case should change.
When `maintain-health --json` returns `experience_usage`, inspect `misleading_records` before trusting high-recall old experience. Misleading or superseded usage means the record needs trigger tightening, confidence lowering, stale review, or replacement guidance.
When `maintain-health --json` returns `graph_quality`, inspect `health_status`, `orphan_code_logs`, `orphan_code_symbols`, `stale_edges`, and anchor coverage before broad query tuning. If `maintain-plan` returns `review_graph_quality`, prefer a focused learn refresh or edge rebuild around affected source paths instead of adding more unrelated memory.
When `graph_signal_quality` is present, inspect `coverage_scorecard` first, then use `top_repair_targets` before broad relearning. The scorecard separates business semantic coverage, log diagnostic coverage, and anchor coverage. Repair only the weak lane: enrich business meaning, add request/session correlation, add route/resource anchors, add reason/error-code fields, or add result/stage fields to the specific log or symbol target.
When `maintain-plan` returns `review_log_observability_gap`, keep the fix in the `log_diagnosis` lane. Patch only the listed log anchors and prefer correlation ids, route/resource, reason/error-code, stage, and result fields over broad logging expansion.
When `active_learning_queue` is present, use it as the first triage view. It ranks query misses, weak graph/log anchors, experience usage outcomes, and low-quality records into one bounded queue. Do not mutate memory from the queue alone; follow the concrete underlying action for the selected item.
When `memory_tiers` is present, use it as the archive-pressure view. Hot and warm records stay query-eligible through existing rules; cold and archive-candidate records need review before stale marking, merging, confidence lowering, or archival. Do not delete memory only because it appears in a tier.
When `action_budget` is present, use `recommended_lanes` to choose the first governance path, then use the lane's `next_command_template` if a focused compact rerun is useful. Use `top_actions` as the first review batch. Read `review_key`, `source_hint`, `priority_reasons`, and `next_command_templates` before rerunning a full plan. The budget is a token-saving triage view, not an execution plan. Always open the underlying action and respect `requires_confirmation`, current source code, conflict state, and user feedback before changing memory.
When token budget is tight or the archive is large, run `maintain-plan --compact --action-limit 3 --json` first. Use `--action-limit 1` for the smallest possible first pass. Use compact mode to choose a review lane, then rerun full `maintain-plan --json` only when you need templates, detailed records, or full action payloads.
When the user asks to focus one governance path, add `--action-lane <lane>` using a lane from `action_budget.counts_by_lane`. If `lane_filter_status` is `no_matches`, inspect `available_lanes` and rerun with a valid lane before concluding there is no work. This filters the budgeted top actions only; still treat the full maintain plan as the source of review truth.
When several golden case files may exist, use `eval-quality --list-gates --cases-dir docs/eval --json` to inspect available gates without mutating the latest quality snapshot, then prefer `eval-quality --cases-dir docs/eval --json` before running individual eval commands. Use `--gate <name>` when reviewing only one quality lane. If it fails, inspect `summary.failed_gate_names` and the failed gate's `next_command_template`, then rerun the specific eval command for full case detail. Use `--strict` only when an empty cases directory should fail, and use `--fail-on-fail` only for script or CI-style checks that need exit code 1.
For end-to-end Agent validation, use `eval-harvest-history` to create review-only real-history drafts or `eval-mutate-arkts` to create non-destructive, oracle-known ArkTS cases. Run `eval-agent-benchmark` with an approved executable Runner to compare baseline and Query Skill variants. Never promote Git drafts to holdout without reviewing the user task, expected files, root-cause category, forbidden directions, and verification path. Treat `maintain-health.agent_benchmark` as operational quality evidence, not project knowledge.
When a project has no golden cases yet, use `eval-seed-cases --target docs/eval/examples --json` to create editable examples. Do not run generated examples as proof until their ids, text anchors, claims, and action specs have been edited against current project memory.
When reviewing retrieval quality after ranking, scoring, learn-business, code graph, or log graph changes, run `eval-retrieval --cases <golden-cases.json> --json` if a golden query file exists. Use missed expected anchors and unexpected bad matches to choose the smallest follow-up: enrich business terms, tighten an experience trigger, mark stale memory, or add a new golden case.
When reviewing experience recording quality after reflect, calibration, or maturity changes, run `eval-experience-evidence --cases <golden-experience-evidence.json> --json` if a case file exists. Use missing profile fields to decide whether the reflection needs evidence, applicability, counter-evidence, or verification details.
When reviewing graph signal coverage after code graph, log graph, learn-business, or log design changes, run `eval-graph-signal --cases <golden-graph-signal.json> --json` if a case file exists. Use missing required repair targets or coverage score failures to decide whether to enrich business terms, improve log diagnostic fields, or refresh graph edges.

When `semantic_provider` shows repeated fallback or `maintain-plan` returns `review_semantic_provider_failures`, inspect the bounded failure reasons and run `eval-semantic` with an approved provider. Do not install or invoke an unreviewed executable from project configuration.
When reviewing governance action behavior after archive, active-learning, or maintain-lane changes, run `eval-governance --cases <golden-governance.json> --json` if a golden governance file exists. Use missing expected actions or unexpected blocked actions as regression evidence.
When reviewing answer grounding after query, graph, log, or experience changes, run `eval-evidence-attribution --cases <golden-evidence-attribution.json> --json` if a case file exists. Use unsupported claims to decide whether the problem is weak retrieval, missing code/log anchors, or an answer that overstates the evidence.

## Guided Review Workflow

When `context` or `impact-scope` reports a missing code anchor, dependency edge, or unlearned changed file, refresh only the named scope before broad relearning. Retrieval interference remains governed through existing `retrieval-feedback`; temporary raw user logs must not be copied into SQLite.

Inspect `graph_quality.edge_governance`, `evidence_runtime`, and `impact_feedback`. Legacy/unverified edges need a focused learn refresh. Repeated `association` chains need runtime correlation, structural mechanism, counter-evidence, or verification before promotion. Impact feedback with missed or flaky cases should tighten test recommendations, not automatically raise memory confidence.

When the user asks to clean, organize, review, or govern memory:

1. Run `doctor`.
2. Run `maintain-health --json`.
3. Inspect `graph_quality`, then `graph_signal_quality`, then `runtime_performance`.
4. If golden cases exist and the task touched ranking, query, graph, governance, or log behavior, run `eval-quality --cases-dir docs/eval --json` first, then rerun a specific eval if one gate fails.
5. Run `maintain-plan --compact --json` first on large archives or low-token sessions; otherwise run `maintain-plan --json`.
6. If `action_budget.top_actions` exists, use it to choose the first bounded review batch.
7. Review maturity, counter-evidence, weak evidence chains, log signal, active-learning, memory-tier, stale, merge, and archive actions in that order.
8. Present grouped actions to the user by risk and type, including open query misses.
9. Wait for confirmation before executing `maintain-status`, `maintain-merge`, or `maintain-promote`.
10. After confirmed changes, run `vault-export`.
11. Treat the vault as a bounded human-readable mirror on large archives. If a generated page says it is truncated, continue full inspection through runtime JSON or direct SQLite-backed commands rather than assuming the vault contains every row.

If an action has `command: null`, draft the needed replacement fact or lesson first, then ask for confirmation.

When `maintain-plan` returns `promote_experience_candidate`, review the reflection as reusable experience. Check `candidate_fields`, `verification_method`, `source_cases`, and `skill_candidate`; do not promote it automatically.
When `maintain-plan` returns `quality_summary`, `low_quality_records`, or `high_value_records`, treat them as ranking aids for review order. Low-quality records need verification, tightening, stale marking, or merge review. High-value records can be reused or reviewed for promotion, but the score does not override current source code or explicit conflict/stale signals.
When `maintain-plan` returns `review_low_quality_memory`, inspect `quality_reasons` before choosing a fix. Prefer tightening the record, lowering confidence, marking stale, or merging duplicates over deleting data.
When `maintain-plan` returns `review_high_value_experience`, prioritize it for reuse or skill-pattern review. This is not permission to create or promote a skill automatically; keep the normal draft/review/promotion gates.
When `maintain-plan` returns `review_missing_counter_evidence`, add negative preconditions, does-not-apply cases, or counter examples before letting the experience act as a reusable rule. If `review_immature_experience` appears, add trigger, repair, verification, or lower confidence. If `review_maturity_regression` appears, inspect misleading or stale signals before keeping the experience active.
When `maintain-plan` returns `review_weak_evidence_chain`, do not discard the experience. Check whether `source_cases` can be linked to a verified Agent-structured `incident_trace:<id>` or whether a code/log anchor should be added through a future reflection. Never send temporary logs to Runtime to manufacture the missing chain.
When `maintain-plan` returns `review_retrieval_feedback`, inspect the feedback query, reason, independent observation count, and supporting feedback IDs. Only stable signals produce this action. Prefer tightening trigger conditions, lowering confidence, marking stale only after confirmation, or superseding with the replacement record if provided. Then execute the supplied resolution commands so reviewed feedback no longer affects ranking. Pending feedback is observation only, not a mutation prompt.
When `maintain-plan` returns `review_experience_usage`, inspect stable outcomes before changing the record. A verified event or the same outcome from two independent tasks is required. `used`, `ignored`, and `superseded` do not directly change rank; prefer tightening scope, lowering confidence, adding `does_not_apply_to`, or marking stale only after checking current source and replacement guidance.
When `maintain-plan` returns `review_active_learning_queue`, treat it as an ordering aid. Inspect `queue_item.lane`, `priority_score`, `source_signals`, and `suggested_action`, then use the specific query miss, graph signal, experience usage, or quality action path for the actual repair.
When `maintain-plan` returns `review_memory_tier`, inspect `record_type`, `record_id`, `tier`, `tier_reasons`, `status`, `use_count`, `last_used_at`, `confidence`, and `quality_score`. Cold records usually need trigger tightening, confidence lowering, merge review, or more evidence. Archive-candidate records need confirmation against current code and source history before stale/archive status changes.
If the action also includes compressed trace-case fields such as `query_rounds`, `useful_followup_focus`, `useful_followup_terms`, `misleading_followup_terms`, `inspection_targets`, or `final_verification_path`, review them as evidence about how the Agent actually converged.
When `maintain-plan` returns `review_skill_pattern_candidate`, treat it as a multi-case aggregation hint, not a ready-made skill. Review `supporting_reflection_ids`, `common_followup_focus`, `common_query_terms`, `supporting_cases`, and `verification_methods` before drafting any skill candidate.
If `draft_path` and `draft_markdown` are present, use them as the proposed review artifact for `docs/skill-candidates/`. Review and edit the draft first; do not treat it as an approved skill.
If `common_steps`, `common_stop_conditions`, `expected_outputs`, or `failure_modes` are present, treat them as the first pass at turning repeated experience into executable skill structure.
If `draft_status`, `package_status`, or `promotion_stage` are present, use them as the current repo-state signal instead of inferring state from file paths alone.
If `draft_review_status`, `package_review_status`, or `review_guidance` are present, use them to decide whether the next step is writing a draft, reviewing a draft, or reviewing a candidate package before any manual promotion.
If `promotion_readiness`, `quality_score`, or `quality_reasons` are present, use them as the runtime's current evidence-strength signal for whether the pattern is only interesting, worth review, or close to manual promotion.
If `helped_reuse_count`, `partial_reuse_count`, `misleading_reuse_count`, `anchor_health`, or `missing_anchor_paths` are present, use them to judge whether the pattern is still grounded in current code or is drifting away from its original anchors.
These are reviewer aids, not permission to skip manual promotion checks.
After `vault-export`, the same grouped pattern appears in `Governance/Skill Pattern Candidates.md` for human review.
That vault page now also mirrors reviewer metadata and the non-overwrite policy for reviewed artifacts, so Obsidian review sees the same guardrails as runtime JSON.
When `maintain-plan` returns `review_incident_strategy_candidate`, treat it as a runtime-incident diagnosis policy candidate rather than a formal skill. Review `goal_symptoms`, `common_log_events`, `recommended_steps`, `verification_paths`, `misleading_signals`, and `log_design_feedback` before drafting it.
After `vault-export`, the same grouped incident strategy appears in `Governance/Incident Strategy Candidates.md`.

When `maintain-plan` returns `review_recurring_incident_fingerprint`, keep it lightweight. Review `goal_area`, `common_log_events`, `dominant_failure_signals`, and `misleading_signals` first, then decide whether the repeated signature is worth drafting into `docs/incident-fingerprints/`. This is for preserving repeated incident shape, not for building a full runtime history store.

When `maintain-plan` returns `review_log_design_gap`, keep the follow-up narrow. Use `goal_area`, `high_value_log_anchor_targets`, and `suggested_log_kinds` to patch one or two high-value logs in the affected code path. Prefer start markers, decision checkpoints, or request/session correlation fields over broad logging expansion.
When `maintain-plan` returns `review_log_observability_gap`, inspect `missing_signal_counts` and `top_targets` first. Add stable event names, correlation, route/resource, reason/error-code, stage, or result fields to those code logs, then rerun a focused learn refresh.
When `governance_summary` or `learn_governance_summary` is present, choose the smallest governance lane that removes the current bottleneck. Prefer `learn_semantic_repair` before `skill_evolution` whenever drift or correction is concentrated in a few files.
When `maintain-plan` returns `review_semantic_patch`, treat it as an anchored code-business semantic repair. Check `anchor_type`, `anchor_key`, `semantic_field`, `existing_value`, `proposed_value`, and `patch_reason` against current source before applying the generated `learn_business_payload_template`.
When the current target field is non-empty and different from the proposed value, route the decision through semantic conflict review instead of overwriting silently.
When `maintain-plan` returns `review_retrieval_interference`, inspect whether the reflection was over-retrieved, previously misleading, or missing narrow trigger boundaries. Prefer lowering confidence, tightening `trigger_condition` / `does_not_apply_to`, or marking it stale before allowing it back into the main query lane.
When `maintain-plan` returns `review_experience_conflict`, compare the older and newer guidance before leaving both active. For procedure or correction conflicts, tighten the trigger boundary and stale the outdated rule if the newer one wins. For semantic patch conflicts, verify the anchor in current source and mark the losing patch superseded or route the difference into `semantic_conflicts`.
When the grouped runtime-incident strategy is ready to be drafted into the repo, use:

```bash
python3 tools/agent_memory.py maintain-incident-strategy-draft \
  --project . \
  --strategy-name "<strategy-name>" \
  --json
```

This writes only `docs/incident-strategies/<strategy-name>.md`. It does not create or promote a formal skill.
When the pattern is ready to be written into the repo as a draft document, use:

```bash
python3 tools/agent_memory.py maintain-skill-draft \
  --project . \
  --pattern-name "<pattern-name>" \
  --json
```

This writes only `docs/skill-candidates/<pattern-name>.md`. It still does not create or update a real skill under `skills/`.
The generated draft includes YAML frontmatter with review metadata such as `artifact_type`, `promotion_status`, `supporting_reflection_ids`, and `common_followup_focus`.
Keep `review_status`, `reviewer`, and `review_notes` in that frontmatter/body pair up to date during human review instead of inventing an external checklist.
If a draft already carries human review metadata, rerunning `maintain-skill-draft` should preserve it. Read `write_action` and `warning` before assuming the runtime rewrote the file.

To write every currently clustered draft in one pass, use:

```bash
python3 tools/agent_memory.py maintain-skill-draft \
  --project . \
  --pattern-name all \
  --json
```

When a reviewed draft should move into a candidate skill package, use:

```bash
python3 tools/agent_memory.py maintain-skill-package \
  --project . \
  --pattern-name "<pattern-name>" \
  --json
```

This writes only `skills/_candidates/<pattern-name>/SKILL.md`. It still does not create or update a formal skill under `skills/<name>/`.
It also writes `skills/_candidates/<pattern-name>/PROMOTION.md` as the manual promotion checklist for the final human step.
The candidate package includes YAML frontmatter with `promotion_status: candidate` and `source_draft` so reviewers can trace where it came from.
Keep the same `review_status`, `reviewer`, and `review_notes` fields when the draft is promoted into `_candidates/`.
If a candidate package already carries human review metadata, rerunning `maintain-skill-package` should preserve it. Read `write_action` and `warning` before assuming the runtime rewrote the file.
Formal promotion into `skills/<name>/` remains manual for now. Follow `docs/skill-promotion-rules.md` before treating a candidate package as a real skill.
For a read-only final gate, use:

```bash
python3 tools/agent_memory.py maintain-skill-promotion-status \
  --project . \
  --pattern-name "<pattern-name>" \
  --json
```

Use its `promotion_blockers` output before attempting any manual copy into `skills/<name>/`.
When `experience_type` is present on a reflection action, keep the governance path aligned:

- `procedure_experience` -> future skill candidate review path
- `correction_experience` -> learn or semantic repair review path

For `review_correction_experience`, prefer the structured repair bundle over ad hoc rewriting:

- `correction_targets`
- `learning_rule_draft`
- `learn_business_payload_template`
- `workflow_steps`

Use these to patch the affected business semantics through `learn-business` at the narrowest possible scope.

When `maintain-plan` returns `review_query_miss`, inspect `suggested_fixes`:

```text
learn_missing_scope
add_business_terms
rewrite_reflection
ignore_noise
```

Choose the smallest fix. A miss caused by missing code context should trigger `agent-memory-learn`; a miss caused by weak business meaning should trigger `learn-business`; a miss caused by absent experience should trigger `agent-memory-reflect`; irrelevant misses can be marked ignored.
When `suggested_query_terms` is present, use those terms first for the next recursive `search` or `context` call. They combine the miss wording with the current code-memory hint anchors.
When `followup_focus` is present, treat it as the intended query-repair scene, such as `route`, `resource`, `log`, or `config`.
When `query_workflow_steps` is present, follow them before broadening the learning scope.

When `maintain-plan` returns `semantic_gap_targets`, treat them as the next enrichment queue. Feed those file, symbol, or log anchors back into `agent-memory-learn` and `learn-business` instead of re-learning broad directories.

When `maintain-plan` returns `learn_business_payload_template`, edit that template in place and send it to:

```bash
python3 tools/agent_memory.py learn-business --project . --payload "<json>" --json
```

Prefer filling the template over inventing a new payload shape. It keeps file, symbol, and log anchors aligned with the existing code wiki rows.
If the template includes `hint_terms` and `hint_context`, use them as the default retrieval anchors for the next `business_terms` and `business_summary` draft.

When `workflow_steps` is present, follow it in order. Treat it as the default local Agent CLI procedure for targeted semantic enrichment.

When `maintain-plan` returns `review_semantic_conflict`, do not replace stored summaries immediately. These conflicts are now durable SQLite governance records and also appear in the vault review pages. Read current source, decide which summary is grounded in the code, then prepare a reviewed replacement in a later governed step.
When `apply_command_template` is present on a conflict action, use it only after that review is complete.

List or close semantic conflicts with:

```bash
python3 tools/agent_memory.py list --project . --type semantic-conflict --json
python3 tools/agent_memory.py conflict-status --project . --id "<id>" --status resolved --resolution "<why>"
python3 tools/agent_memory.py conflict-apply --project . --id "<id>" --resolution "<why incoming summary is correct>" --decision-note "<evidence>" --replacement-source "<source anchor>"
```

Use `conflict-apply` only after checking current source and deciding the incoming summary is the right replacement. It applies the stored incoming summary to the target file, symbol, or log and marks the conflict `applied`. The runtime now requires the target to resolve to exactly one stored row; ambiguous symbol or log targets are rejected for manual cleanup first.

## Governance Actions

Mark a record stale, archived, rejected, merged, or active:

```bash
python3 tools/agent_memory.py maintain-status \
  --project . \
  --type semantic \
  --id "<id>" \
  --status stale \
  --reason "<why>"
```

Merge duplicate semantic facts:

```bash
python3 tools/agent_memory.py maintain-merge \
  --project . \
  --type semantic \
  --ids "3,8" \
  --fact "<consolidated fact>" \
  --json
```

Promote an episode into a durable semantic fact:

```bash
python3 tools/agent_memory.py maintain-promote \
  --project . \
  --episode-id "<id>" \
  --fact "<durable fact>" \
  --json
```

Promote a high-quality reflection into a durable semantic fact:

```bash
python3 tools/agent_memory.py maintain-promote \
  --project . \
  --reflection-id "<id>" \
  --fact "<durable fact>" \
  --json
```

Mark a query miss reviewed, resolved, or ignored:

```bash
python3 tools/agent_memory.py miss-status \
  --project . \
  --id "<id>" \
  --status resolved \
  --resolution "<what fixed the miss>"
```

Open misses are merged by normalized query text. Use `miss_count` and `last_seen_at` to prioritize recurring retrieval gaps before one-off misses.

Agent-structured incident review actions can appear in `maintain-plan`:

- `promote_incident_trace_to_reflection`: a resolved, verified structured outcome has a current code anchor and can be reviewed as a diagnosis reflection.
- `complete_incident_verification`: a structured outcome still lacks a current anchor or causal closure evidence.
- `review_legacy_incident_trace`: an old Runtime-derived trace is quarantined and must not be promoted.

Do not promote an outcome automatically. Check current source and the Agent's evidence, then run `agent-memory-reflect` with the returned `reflection_payload_template` if the result is reusable.

## Refresh Indexes

```bash
python3 tools/agent_memory.py wiki-index --project .
```

Refreshing the wiki also refreshes extracted code log statements and the generated file/function/log edges.

## Sync Obsidian Mirror

```bash
python3 tools/agent_memory.py vault-export --project .
python3 tools/agent_memory.py vault-index --project .
```

Rules:

- SQLite is the source of truth.
- Obsidian is a generated review mirror.
- Do not modify shell profiles.
- Report failed `doctor` checks exactly.
- `agent-memory-query` should stay fast; run heavier governance through this maintain skill.
- Do not auto-delete memory. Prefer stale, merge, archive, or reject status changes.
- `maintain-plan` is read-only. It proposes actions; it does not mutate memory.
- Prefer `maintain-plan --compact --action-lane <lane> --json` after a Lane is known. Check `execution_scope`: focused summaries cover only the selected Lane.
- Use `--verify-graph-quality` only for an explicit graph audit; normal learn and rebuild commands invalidate the revision-bound runtime snapshot automatically.
- Merge only when the replacement fact is more precise than all source facts.
- Promote only durable lessons, not task logs.
- Treat `rewrite_reflection` and `mark_stale` actions from `maintain-plan` as confirmation-required reflection quality actions.
- Treat `promote_experience_candidate` as a review signal, not an automatic promotion.
- Treat `review_query_miss` actions as low-risk signals that may require learning a missing path, adding business terms, rewriting a reflection, or ignoring noise.
- Treat `add_business_terms` actions as targeted enrichment work; prefer patching the listed semantic gaps over re-indexing large code scopes.
- Vault export includes generated code log statement, memory edge, incident trace, query miss, semantic conflict, reflection quality, and experience candidate pages for review.

## Task-End System Review Handoff

For an ordinary maintenance task that closes with an observed Memory system signal, hand
bounded observations and the retained task identity to Reflect's installed
[system-review protocol](../agent-memory-reflect/references/system-meta-review.md).
Do not recursively review meta-review/system-improvement work or treat every health call
as a task boundary. Respect stops/budgets; a missing reference is a capability gap, not
evidence that an automatic hook or review ran.
